# Component & pattern catalog

Exact treatment per card in the Rhapsody Design System (September 2026). Each corresponds to a
`components/*.html` file in the repo. When you're in the repo, open that file for the live markup and
reusable classes; otherwise use these specs. All items link `tokens.css` and pull logo art from
`assets/`.

## Contents
- Foundations: Brand expression · Color · Typography · Layout & spacing · Pathways · Corners & shape
- Brand: Logo & wordmark
- Components: Buttons · Charts · Partner logos · Quotes · Stats · Tables · Dot accents
- Graphic devices: Devices at a glance · Dots · Fluid dot pattern · Big dot · Light devices
- Iconography: Icon library
- Imagery: Illustration · Photography & portraits
- Patterns: Hero · Email · Email signature · Social · Product launch · Name lockup · Display ads · Social templates · PowerPoint · Letterhead (Word) · Technical documents · Ebooks
- Reference: Quick corrections log

---

## Foundations

**Brand expression.** Visual principles, AI direction, and the decision hierarchy. Start here for the
"why": engineered but human. Dots are precise and rational; light devices are warm and atmospheric.
Restraint is the house style — clean, confident, few colors, lots of air.

**Color.** See SKILL.md §1. Default hierarchy White/Navy + Rhapsody Blue + one optional accent; ≤3
brand colors. Tertiary (purple/orange) restricted to accent/emphasis/data-viz. No text on teal. No
custom gradients (except the Aurora glow, which is also the web hero background, and photo scrims). On navy, text accents are light blue; Rhapsody Blue on navy is graphics and the pill only. Teal is immutable (#23C5BF, never darkened
for contrast): teal type on navy only; on light grounds teal is accent-only (tick / accent line /
seam) beside navy text — see the card's "Teal in small applications" section.

**Typography.** See SKILL.md §2. Poppins Regular body/headings, Medium hero; IBM Plex Mono eyebrows
only. Two-tone headline: light blue on navy, Rhapsody Blue on white; never on a blue ground. `strong` = Medium. Shorten copy rather than
crush type. Date and name lockups use the mono for the small label line.

**Layout & spacing.** Keep a **clear margin** of ~6–7% of the shorter side around a composition. The
**teal seam** (a thin teal rule, often on a bottom or dividing edge) is the signature separator. The
**module accent line** marks the top or side of a content module. Generous whitespace; align to a
consistent grid; don't crowd.

**Pathways.** Color-code journeys/paths consistently. Example coding: **Build = blue**, **Automate =
teal**. Pathways use the **same color order as charts** (navy → blue → teal → purple → orange → light
blue). Keep a path's color stable wherever it recurs (wayfinding).

**Corners & shape.** Square the top two corners, round the bottom two (≈12px) on module/content frames.
Use that container for ONE element per page; lists are bullets or steps and specs are tables, never stacked boxes.
Pills are CTA-only. Keep the corner treatment consistent across a page/deck.

## Brand

**Logo & wordmark.** See the REQUIRED block at the top of SKILL.md and §3. Full color (navy bar + blue
wordmark, `assets/logo-on-light.*`) on white and light only. Navy, Aurora over navy, Rhapsody Blue, and any
dark background or photo = the all-white logo (`assets/logo-on-dark.*`) at every size, in every format, on
every page; check each logo before delivering. Monogram for tight spaces only (navy-and-blue on light, all white on navy, Aurora, and Rhapsody Blue). Clear space =
the "R" mark on all sides. Product & co-brand lockups keep "Rhapsody" on the mark. Never modify,
recolor, rotate, or overlay.

**Rhapsody Axon mark.** The robot character for Rhapsody Axon™. Full color on light (primary), navy
one-color on light, reversed on navy/dark, white on dark and on Rhapsody Blue. Never full color on dark.
Files in _Asset Library > Logos > _Rhapsody Product Logos > Axon Mark; six animated states (animated SVG light/dark, PNG sequences). Use as provided.

**Axon Connected badge.** Vendor status mark for a published Rhapsody Axon™ Broadcast playbook (never
certification or endorsement). Navy/Blue Circle and Blue Bar on light; White Circle/Bar on gray, navy,
blue. Clear space ¼ width (circle) / ¼ height (bar); min 64px / 160px. Link to the Directory playbook
page; alt "Axon Connected badge"; approved wording only. Files in _Asset Library > Logos > _Rhapsody Product Logos > Axon Broadcast Badge.

## Components

**Buttons & CTAs.** **Pill** shape (fully rounded). **Primary** = Rhapsody Blue fill, white label.
**Secondary** = outline (blue or navy stroke) on light, or white/blue outline on dark. **Text link +
arrow** for tertiary actions (label + "→"). One primary action per view. Verb-led labels.

**Charts & graphs.** Flat, no gradients, minimal gridlines. Series color order: Rhapsody Blue → teal →
purple → orange → light blue → navy, gray for the remainder; two series = Rhapsody Blue + navy.
Same order feeds pathways. Label directly where possible; keep to as few series as the story needs.
Types shown: bar, line, stacked bar, donut.

**Website feature image.** 1200×630, export 2×. Fixed system: navy + Aurora glow top right, text
left (1.5fr) / motif right (1fr), 90px side padding. Four slots: IBM Plex Mono teal eyebrow (17px),
Poppins Medium 48px headline with a light-blue emphasis (46px if long, 58px for 1–3-word stacks), a
line-art motif (viewBox 200×180; #B4D8FF outlines 3–3.4; #3D6587 connectors 3.5 drawn first; teal
check badge + one accent; grounded pulse; optional mono text chips like EHR/FHIR; never a redrawn
third-party logo), and a 25px lockup. No single-word lines. Template:
`templates/feature-image/` (Claude Design `FeatureImage.dc.html`; code `source/` + `render-feature.mjs`).

**Partner logos (brackets).** Present partner/customer logo walls inside a **bracket treatment** —
thin brackets frame the set. Keep partner logos monochrome/neutral where possible so they sit evenly.

**Quotes & testimonials.** Quote card, testimonial, and customer-quote card variants. Large quote in
Poppins; attribution via the name lockup (name, title, company). On navy, the Aurora glow is the
appropriate backing device for a testimonial. Keep quotes to 1–2 sentences.

**Stats.** Number-led stat cards — large numeral (Poppins Medium), short descriptor beneath. Numbers
only in the big slot; keep descriptors short. Group in rows; align baselines.

**Tables.** **Navy header** row (white text), alternating white / gray-blue (`--grayblue`) body rows,
an optional **blue result column** for the key figure, and small **status tags** (pill chips). Thin
`--lgray` hairlines. Squared-top/rounded-bottom frame.

**Dot accents.** Small dot-based accents: framing/diagram shapes and the **dot-row accent** (a short
run of dots as a divider or emphasis mark). A restrained way to bring the dots device into a component
without a full field.

## Graphic devices

**Devices at a glance.** The master overview: each device, its meaning, its color lead, and when to
use it. Consult it to choose between dots and a light device — and remember, only one per layout.

**Graphic Devices library.** All device masters (fluid dot 42, big dot ecosystem 9 and corner crops 12,
Aurora Glow 12) are verbatim files in SharePoint _Asset Library > Graphic Devices,
mirrored as PNG in `assets/graphic-devices/`. Use as supplied.

**Dot grid.** Retired (Nov 2026); use the fluid dot pattern instead.

**Fluid dot pattern.** A half-tone dot grid — identical dots that gather into a dense core and dissolve fluidly outward; registers white-on-navy, white-on-blue, dots-on-white, multicolor-on-navy. Replaces the retired scattered field.
Structured dispersion with defined anchors. Do: keep density purposeful and directional. Don't:
random scatter, or graduated sizing.

**Big dot.** A closed, approved family — one per background/placement/format plus three variants, as
transparent SVG + 2× PNG. Use as-is, flipped, or rotated 90°. Never hand-build or restyle. Anchor +
companion colors are fixed by the background; the anchor is never the background hue.

**Light devices.** Aurora is the one light device — a single glow with range, soft wash to flowing, that allows movement (navy only, teal-led). Burst, Plexus, and the separate Aurora ribbon are retired (Oct 2026).
**Navy grounds only.** Glow = teal/blue/purple, never orange, ≤3 colors. The soft wash may sit behind copy
(website hero) if contrast holds. Approved masters, not effects.

## Iconography

**Icon library.** Use the official FY27 icon library only (SharePoint: Brand Package FY27 > Icon
Library; 271 outline icons). Two SVG versions: Color (blue) and Color (White). 24px grid, stroke set per icon (mostly 0.85–0.9, down from 1.7), never edited.
Feature icons in a tile built to the recipe (44px, 11px corners, 24px glyph; `.icon-tile` classes). SVGs: `assets/icons/svg/{blue,white}/`. Functional check/cross at weight 3.
Never draw icons or use another set. Two-color icons, icon-on-circle art, and the hand-drawn reference
set are retired.

## Imagery

**Illustration.** Legacy line-art, spot illustration, and character/cartoon scenes are retired. Use
photography, product/interface imagery, diagrams, data viz, or the abstract devices instead.

**Photography & portraits.** Bright, natural-lit, tech-forward, faces-forward, inclusive. Avoid
tech-noir, blur, harsh flare, backs-to-camera, staged/stiff poses. Portrait treatments: Rhapsody Blue ring
(single blue line, no navy band; 2–3px small, 4–6px feature) by default, arc accent, rounded-rectangle card,
editorial split. The navy-and-blue ring is the website hero badge only.

## Patterns

**Hero.** Three registers: **light** (white ground, navy/blue type), **dark** (navy ground, white headline
with an optional light-blue two-tone phrase, optional light device), and **photography** (image with copy on the calm
side). Structure: eyebrow (mono) → headline → subhead → single CTA. Keep one graphic device.

**Email template.** Header banner options: Aurora glow, big dot, or photo. Teal seam under the header.
Single CTA. Body in Poppins Regular. Notes for Pardot/marketing-automation build included in the card.

**Email signature.** Employee signature: wordmark, teal divider, name lockup, and certifications row.
Deliverable package (HTML + IT/employee setup) lives in `deliverables/signature-package/`.

**Social posts.** 1:1 square posts plus a quote banner. One device per post (dots or a light device).
Logo present; copy short and legible; keep blue backgrounds readable (bump type weight/size, not clutter).

**Product launch announcement.** Launch unit: product name, **Aurora** glow on navy, one CTA. Use for a
breakthrough/announcement moment.

**Name lockup.** Attribution block: name, title, company. Rules for logo vs. written company name, and
pairing with a portrait treatment. Small label line often set in mono.

**Display ads (blue-first).** Rhapsody Blue ground by default (navy occasionally), **logo always
prominent**, **very few large words** (billboard style), **one clear action**. Covers every IAB size.
Canvas template: `templates/display-ads/DisplayAds.dc.html`. This pattern is intentionally louder and
simpler than the rest of the system — resist adding detail.

**PowerPoint deck template.** The reference for every Rhapsody slide and deck, in PowerPoint or in
Claude: the 2026 PowerPoint template (November 2026, work in progress, in use now) at SharePoint >
Marketing > Private > Graphic Design > Projects > 2026 > 2026 Rebrand > PPT Template (https://rhapsodyhealth.sharepoint.com/:p:/r/Shared%20Documents/Marketing/Private/Graphic%20Design/Projects/2026/2026%20Rebrand/PPT%20Template/Rhapsody%20PowerPoint%20Template%20-%202026%20KASS%20.pptx?d=w997112cd3f564c969bec4b6f4af82261&csf=1&web=1&e=yTQhhs).
Layouts: cover (headline, deck name, mono "PREPARED BY … · DATE" eyebrow, cover image), title and
section, agenda (AGENDA eyebrow, "What we'll cover," topics 01–07), two-, three- and four-column
content (small title plus three points), four numbered titles, stats (25k+ provider connections
worldwide, 100% healthcare focused, >7,000 customers through OEM partners, 24/7 global support),
speaker, quote. Footer on every slide after the cover: "© 2026 Rhapsody. All rights reserved." and
the slide number. Replace the template's old dots with fluid dot masters and its placeholder icons
with FY27 library icons; never copy them. The earlier 65-slide master is retired. For deck-editing
mechanics load the `pptx` skill; for slide copy and Rhapsody Axon™ naming load `rhapsody-brand`.

**Ebooks.** 816×1056 letter pages; padding 56/60/72; header stack (44×3 blue rule, Plex Mono
eyebrow 12px blue, H2 Poppins 400 36px, intro 16px/1.6); running footer with logo (108px) + title +
page number in Plex Mono 10px gray; cover and CTA navy, proof pages may be navy (light-blue accents).
Cards with 3px top border and bottom-only 12px radius; image slots 260–330px; FY27 icon tiles; feature
rows with hairlines; two-column checklists; stats 52–64px; navy/blue closing panels; pill CTA without
arrow. One boxed element per page. Fixed page order and a blue-accented takeaway closing each page.
Campaign illustration and badges isolated to cover, CTA, and the field-guide page. See the Ebooks card.

**Social templates.** Every social graphic starts from the approved Adobe Express templates (1200×628):
product release (2 options; button allowed here only; option 2 can swap the badge for a product
screenshot), webinar (1/2/3 speakers × flat navy or Aurora Glow), event, customer story (4 options:
stat light, stat navy, headline Aurora, headline blue with circles), employee spotlight (3 options).
Title Case headlines with no end period; one mono eyebrow naming the post type; all-white logo on
navy/Aurora/blue, primary on light gray; co-brand lockup with a thin plus; speakers and employees
black and white in the Rhapsody Blue ring; the templates' dot and circle art is approved in these
templates only. Links and option details: see SKILL.md and the Social templates card.

**Email signature banners.** Three layouts from the Express Email Signature template (event on blue,
event on Aurora Glow, content with device mockup); one banner below the text signature, linked.

**Letterhead (Word).** The default for letters and everyday Word documents. One letterhead per office,
as .dotx (SharePoint > Marketing > Private > Graphic Design > Templates > Document Templates >
Letterhead) and as .docx in this skill's `assets/letterhead/`: US Boston (One Beacon Street, Suite
16400, Boston, MA 02108; +1 857-277-5678), UK Bristol (Suite 2, Ground Floor, Templeback, 10 Temple
Back, Bristol, BS1 6FL), APAC Shanghai (Suite 06, 47th Floor, Hong Kong New World Tower, No. 300 Huai
Hai Zhong Road, Huang Pu, Shanghai 200021). Use the sender's office, US Boston if unknown. Page 1:
logo, tagline, hairline, office address footer. Page 2 on: small logo and hairline, "rhapsody.health ·
Page N." Arial 11pt navy, US Letter, 1in side margins. Start from the file and replace the
placeholders; never rebuild the header. Technical documents use their own templates.

**Technical documents.** White papers, release notes, and customer security advisories share one
system, modeled on the approved eMudhra advisories (`examples/technical-documents/`). Cover: white,
primary logo top left, white-ground fluid dots in Rhapsody Blue top right, mono eyebrow (document
type), two-tone Poppins Medium title (one Rhapsody Blue phrase), subtitle, hairline, four-column meta
row with blue mono labels. Interior: running header (logo left, mono label right, hairline), footer
document line + page number; page 2 repeats the title over an open contents list (no box; blue mono
numbers, hairline below). Sections open with a short blue rule + "SECTION 01" in spaced blue mono, then Poppins
Medium H1; subsections numbered "3.1" in blue mono. Callout = gray-blue + 3pt blue left rule +
Medium lead-in. Assessment panel = gray-blue + blue top rule, mono label, large blue value (e.g.
Likelihood: Low). Warning panel = navy top rule ("What not to do"). Audience cards = two outlined
cards (Rhapsody Cloud / customer-hosted). Tables = navy header, alternating gray-blue rows; key-value
tables with hairlines. Code = IBM Plex Mono on gray-blue (blocks and inline). Round bullets,
numbered steps with Medium lead-ins, underlined blue links. Word templates (.dotx) for all three in
`templates/word-documents/`.

## Reference

**Quick corrections log.** The running list of retired elements and confirmed direction. Retired: busy
circle/photo/icon-overlay montages; legacy line-art and cartoon scenes; two-tone icons; thick color
rings on portraits; squiggle-line-with-dots. Confirmed: multicolor dots approved; dots always
structured; bright natural-lit photography; single outline icon family; new approved treatments
(bracket logos, dot-row accent, white + light-blue headline on dark, teal separator).
